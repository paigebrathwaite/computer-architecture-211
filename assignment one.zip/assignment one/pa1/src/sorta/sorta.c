#include <stdio.h>
#include <stdlib.h>
#include <string.h>



//this has to go first or else it's implicit function declaration
void bubbleSort(char **args, int length) {
   
    for (int i = 0; i < length - 1; i++) {
        for (int j = 0; j < length - i - 1; j++) { // don't recheck sorted elements 

            if (strcmp(args[j], args[j + 1]) > 0) { 
                
                //perform a swap
                char *temp = args[j];
                args[j] = args[j + 1];
                args[j + 1] = temp;

            }

        }
    }
}

int main(int argc, char **argv){

    // check to see if there are enough arguments to perform 
    if (argc == 1){

        printf("Your input is not long enough. \n");
        return 1;
    }

    bubbleSort(argv + 1, argc - 1); /*"start on the second element of argv (argv[1]) to not include the filename" and  
                                    one less number of arguments to not include the filename */

    for (int i = 1; i < argc; i++) {

        printf("%s\n", argv[i]);

    }

    return 0;

}
