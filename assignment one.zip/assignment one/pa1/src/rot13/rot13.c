#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{

    // check to see if there are enough arguments to perform rot13
    if (argc == 1)
    {

        printf("Your input is not long enough. \n");
        return 1;
    }

    // // check file 
    // for (int i = 1; i < argc; i++)
    // {
    //     printf("%s\n", argv[i]);
    // }

    char rot13[100];
    strcpy(rot13, argv[1]);

    // printf("%s\n ", rot13); // just check to see if it copies correctly
    //  printf("%c\n ", rot13[1]);

    for (int i = 0; rot13[i] != '\0'; i++)
    {

        char temp = rot13[i];
        // printf("temp is currently %c", rot13[i]);

        if (isalpha(temp))
        {

            // the next two ifs are for lowercase letters
            if (temp >= 97 && temp <= 109)
            {
                rot13[i] = temp + 13;
            }
            else

                if (temp >= 110 && temp <= 122)
            {
                rot13[i] = (temp + 13) - 26;
            }

            // these are for uppercase letters
            if (temp >= 65 && temp <= 77)
            {
                rot13[i] = temp + 13;
            }
            else

                if (temp >= 78 && temp <= 90)
            {
                rot13[i] = (temp + 13) - 26;
            }
        }

        printf("%c", rot13[i]);
    }

    // printf("%s\n ", argv[0]);

    printf("\n"); // to get rid of the percent

    return 0;
    
}
