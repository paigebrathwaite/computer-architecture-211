#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


#ifndef DEBUG
#define DEBUG 0
#endif

// // gcc -g -std=c99 -Wall -Wvla -DDEBUG=1 -fsanitize=address,undefined -o truthtable truthtable.c 
// //gcc -g -std=c99 -Wall -Wvla -DDEBUG=0 -fsanitize=address,undefined -o truthtable truthtable.c  --> no debug statements

#define MAX_VARS 100  // Adjust as needed for the number of variables
#define MAX_GATES 100 // Adjust for the number of gates
#define MAX_PARAMS 64


typedef enum { AND, OR, NAND, NOR, XOR, NOT, PASS, DECODER, MULTIPLEXER } kind_t;

typedef struct {
    kind_t kind;   
    int size;      // DECODER and MULTIPLEXER, n
    int *params;   
} gate_t;

int variable_count = 0;         // number of unique variables
int input_count = 0;
int output_count = 0; 
int variable_map[MAX_VARS];     // map variable names to indices
char variable_names[MAX_VARS][17]; // store names of variables
gate_t gates[MAX_GATES];        // store all gates
int gate_count = 0;             // track the number of gates

int get_variable_index(const char *name) {
    for (int i = 0; i < variable_count; i++) {
        if (strcmp(variable_names[i], name) == 0) {
            return i;
        }
    }
    // Add new variable
    if (variable_count >= MAX_VARS) {
        fprintf(stderr, "maximum number of variables has been reached\n");
        exit(1);
    }

    strncpy(variable_names[variable_count], name, 16);
    variable_names[variable_count][16] = '\0'; // null termination
    return variable_count++;
}


void parse_gate(FILE *input, const char *directive) {
    if (strcmp(directive, "INPUT") == 0) {
        int n;

        if (fscanf(input, "%d", &n) != 1) {
            if (DEBUG) fprintf(stderr, "could not read the number of inputs\n");
            exit(1);
        }

        input_count = n;
        for (int i = 0; i < n; i++) {
            char name[17];
            if (fscanf(input, "%16s", name) != 1) {
                if (DEBUG) fprintf(stderr, "could not read the name of the variable\n");
                exit(1);
            }
            get_variable_index(name); // add the input name into the list 
          
        }
    } else if (strcmp(directive, "OUTPUT") == 0) {
        int n;
        if (fscanf(input, "%d", &n) != 1) {
            if (DEBUG) fprintf(stderr, "could not read the number of outputs\n");
            exit(1);
        }
        output_count = n;
        for (int i = 0; i < n; i++) {
            char name[17];
            if (fscanf(input, "%16s", name) != 1) {
                if (DEBUG) fprintf(stderr, "Error: Failed to read output variable name\n");
                exit(1);
            }
            get_variable_index(name);
        }

    } else {
        // parsing a logic gate
        gate_t gate = {0}; // initialize all fields to 0
        if (strcmp(directive, "AND") == 0) gate.kind = AND;
        else if (strcmp(directive, "OR") == 0) gate.kind = OR;
        else if (strcmp(directive, "NAND") == 0) gate.kind = NAND;
        else if (strcmp(directive, "NOR") == 0) gate.kind = NOR;
        else if (strcmp(directive, "XOR") == 0) gate.kind = XOR;
        else if (strcmp(directive, "NOT") == 0) gate.kind = NOT;
        else if (strcmp(directive, "PASS") == 0) gate.kind = PASS;
        else if (strcmp(directive, "DECODER") == 0) gate.kind = DECODER;
        else if (strcmp(directive, "MULTIPLEXER") == 0) gate.kind = MULTIPLEXER;
        else {
            if (DEBUG) fprintf(stderr, "Error: Unknown directive '%s'\n", directive);
            exit(1);
        }

        //if (DEBUG) printf("%s \n", directive);

        int num_params = 0;

        // if DECODER or MULTIPLEXER, read the size and calculate num_params
        if (gate.kind == DECODER || gate.kind == MULTIPLEXER) {
            if (fscanf(input, "%d", &gate.size) != 1) {
                fprintf(stderr, "failed to read size for %s\n", directive);
                exit(1);
            }
            if (gate.size < 1 || gate.size > MAX_PARAMS) {
                fprintf(stderr, "invalid size %d for %s\n", gate.size, directive);
                exit(1);
            }
            num_params = (gate.kind == DECODER) ? gate.size + (1 << gate.size) : (1 << gate.size) + gate.size + 1;
            if (DEBUG) {
            printf("MULTIPLEXER parsed: size=%d, num_params=%d\n", gate.size, num_params);
            }

        } else {
            num_params = (gate.kind == NOT || gate.kind == PASS) ? 2 : 3;
        }

        if (num_params > MAX_PARAMS) {
            fprintf(stderr, "Error: Too many parameters for gate type %s\n", directive);
            exit(1);
        }

        gate.params = malloc(num_params * sizeof(int));
        if (!gate.params) {
            fprintf(stderr, "Error: Memory allocation failed for gate parameters\n");
            exit(1);
        }

        // read parameters
       for (int i = 0; i < num_params; i++) {
            char name[17];
            if (fscanf(input, "%16s", name) != 1) {
                if (DEBUG) fprintf(stderr, "Error: Failed to read parameter name for gate\n");
                exit(1);
            }

            // check if the parameter is a constant
            if (strcmp(name, "0") == 0 || strcmp(name, "1") == 0) {
                gate.params[i] = (strcmp(name, "1") == 0) ? 1 : 0; // Store 1 or 0 directly
                if (DEBUG) printf("Parameter %d is a constant: %d\n", i, gate.params[i]);
            } else {
                gate.params[i] = get_variable_index(name); // Map variable name to index
                if (DEBUG) printf("Parameter %d is a variable index: %d\n", i, gate.params[i]);
            }

            // validate parameter indices
            if (gate.params[i] < 0 || gate.params[i] >= MAX_VARS) {
                if (DEBUG) fprintf(stderr, "Error: Gate parameter index %d out of bounds\n", gate.params[i]);
                exit(1);
            }
        }

        // add the gate to the list
        if (gate_count >= MAX_GATES) {
            if (DEBUG) fprintf(stderr, "Error: Exceeded maximum number of gates\n");
            exit(1);
        }
        gates[gate_count++] = gate;

        
    }
}

void parse_file(FILE *input) {
    char directive[17];
    while (fscanf(input, "%16s", directive) != EOF) {
        if (strcmp(directive, "INPUT") == 0 ||
            strcmp(directive, "OUTPUT") == 0 ||
            strcmp(directive, "AND") == 0 ||
            strcmp(directive, "OR") == 0 ||
            strcmp(directive, "NAND") == 0 ||
            strcmp(directive, "NOR") == 0 ||
            strcmp(directive, "XOR") == 0 ||
            strcmp(directive, "NOT") == 0 ||
            strcmp(directive, "PASS") == 0 ||
            strcmp(directive, "DECODER") == 0 ||
            strcmp(directive, "MULTIPLEXER") == 0) {
            parse_gate(input, directive);
        } else {
            fprintf(stderr, "rrror: unknown directive '%s'\n", directive);
            exit(1);
        }
    }
}

int get_input(int param, int *values) {
    if (param == 0 || param == 1) {
        return param; // Constant input
    }
    return values[param]; // Variable input
}


void compute_truth_table() {
    int num_rows = 1 << input_count; // total rows in truth table
    int values[MAX_VARS] = {0};     // store values of variables

    

    for (int row = 0; row < num_rows; row++) {
        // assign binary values to inputs
        for (int i = 0; i < input_count; i++) {
            values[input_count - 1 - i] = (row >> i) & 1; // Reverse bit order for big-endian
        }
        
        // reset all other values
        for (int i = input_count; i < variable_count; i++) {
            values[i] = 0;
        }


        // evaluate gates
        for (int i = 0; i < gate_count; i++) {
            gate_t *gate = &gates[i];
            int *p = gate->params; // Parameters of the gate
            int result = 0;

            // int x = (p[0] == 0 || p[0] == 1) ? p[0] : values[p[0]];
            // int y = (p[1] == 0 || p[1] == 1) ? p[1] : values[p[1]];


            switch (gate->kind) {
                case AND:
                    result = (values[p[0]] & values[p[1]]) & 1;
                    //printf("Gate %d: kind = %d, inputs=(%d, %d), resul = %d \n", i, gate->kind, values[p[0]], values[p[1]], result);
                    //printf("Evaluating AND Gate: x=%d, y=%d\n", values[p[0]], values[p[1]]);
                    //case AND:
                    //result = x & y;
                    values[p[2]] = result;
                    break;
                    //printf("Result for Gate: %d stored in values[%d] = %d\n", gate->kind, p[2], values[p[2]]);
                    //break;
               case OR:
                    //printf("OR Gate: x=%d, y=%d\n", values[p[0]], values[p[1]]);
                    result = (values[p[0]] | values[p[1]]) & 1;
                    //printf("Gate %d: kind = %d, inputs=(%d, %d), result = %d \n", i, gate->kind, values[p[0]], values[p[1]], result);
                    //printf("Result: %d\n", result);
                    values[p[2]] = result;
                    break;
                case NOT:
                    result = !values[p[0]];
                    // if (DEBUG) printf("The value of values[p[1]] is %d\n", values[p[1]]);
                    values[p[1]] = result;
                    break;
                case XOR:
                    result = values[p[0]] ^ values[p[1]];

                    //printf("The value of values[p[0]] is %d and the value of values[p[1]] is %d\n", values[p[0]], values[p[1]]);                   
                    values[p[2]] = result;
                    //printf("Result for Gate: %d stored in values[%d] = %d\n", gate->kind, p[2], values[p[2]]);
                    break;
                case NAND:
                    //printf("NAND Gate: x=%d, y=%d\n", values[p[0]], values[p[1]]);
                    //printf("Gate %d: kind = %d, inputs=(%d, %d), resul = %d \n", i, gate->kind, values[p[0]], values[p[1]], result);
                    result = ~((values[p[0]] & values[p[1]])) & 1;
                    //printf("Result: %d\n", result);
                    values[p[2]] = result;
                    break;
                case NOR:
                    //printf("NOR Gate: x=%d, y=%d\n", values[p[0]], values[p[1]]);
                    result = ~((values[p[0]] | values[p[1]])) & 1;
                    //printf("Gate %d: kind = %d, inputs=(%d, %d), resul = %d \n", i, gate->kind, values[p[0]], values[p[1]], result);
                    //printf("Result: %d\n", result);
                    values[p[2]] = result;
                    break;
                case PASS:
                    result = values[p[0]];
                    values[p[1]] = result;
                    break;
                case DECODER: {
                    int selector = 0;
                    for (int j = 0; j < gate->size; j++) {
                        selector = (selector << 1) | values[p[j]];
                    }
                    for (int j = 0; j < (1 << gate->size); j++) {
                        values[p[gate->size + j]] = (j == selector);
                    }
                    break;
                }
                case MULTIPLEXER: {
                int num_selectors = gate->size;
                int num_inputs = 1 << num_selectors;
                int selector = 0;

                // Calculate selector value
                for (int j = 0; j < num_selectors; j++) {
                    selector = (selector << 1) | values[p[num_inputs + j]];
                    // printf("the value of values[p[num_inputs + j]] is %d\n", values[p[num_inputs + j]]);
                    // printf("the value of the selector is %d\n", selector);
                }

                // validate selector and assign output
                if (selector < num_inputs) {
                    int mapped_input = p[selector]; // Index of the selected input
                        if (mapped_input == 0 || mapped_input == 1) {
                            // Direct constant input (0 or 1)
                            result = mapped_input;
                        } else {
                            // Variable input
                            result = values[mapped_input];
                        }
                    //printf("Mapped input index: %d, value: %d\n", mapped_input, values[mapped_input]);


                    //printf("The result is %d\n", result);
                    values[p[num_inputs + num_selectors]] = result;

                } else {
                    if (DEBUG) {
                        fprintf(stderr, "Error: Selector out of bounds for MULTIPLEXER (selector=%d, num_inputs=%d)\n", selector, num_inputs);
                        fprintf(stderr, "Expected selector in range [0, %d)\n", num_inputs);
                    }
                    exit(1);
                }
                break;
            }

                default:
                    fprintf(stderr, "Error: Unknown gate type\n");
                    exit(1);
            }

        
        }


        //print inputs
        for (int i = 0; i < input_count; i++) {
            printf("%d", values[i]);
            if (i < input_count - 1) {
                printf(" ");
            }
        }

        printf(" | ");

        // print outputs
        for (int i = input_count; i < input_count + output_count; i++) {
            printf("%d", values[i]);

            if (i < input_count + output_count - 1) {
                printf(" ");
            }

        }

        printf("\n");

    }
}


int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <circuit_file>\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        perror("error opening file");
        return 1;
    }

    parse_file(input);
    fclose(input);

    compute_truth_table();
    return 0;
} 